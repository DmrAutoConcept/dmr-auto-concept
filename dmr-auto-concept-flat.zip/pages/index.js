import DMRHome from "../components/ui/home";
export default function Home() {
  return <DMRHome />;
}
